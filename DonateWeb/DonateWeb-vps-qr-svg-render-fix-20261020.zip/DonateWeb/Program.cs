using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using DonateWeb.Data;
using DonateWeb.Models.Enums;
using DonateWeb.Services;
using DonateWeb.Areas.Admin.Services;
using DonateWeb.Areas.Widgets.Services;
using DonateWeb.Security;

var projectDir = Directory.GetCurrentDirectory();
if (!Directory.Exists(Path.Combine(projectDir, "Views")))
{
    var candidate = AppContext.BaseDirectory;
    while (!string.IsNullOrEmpty(candidate) && !Directory.Exists(Path.Combine(candidate, "Views")))
    {
        var parent = Directory.GetParent(candidate);
        if (parent == null) break;
        candidate = parent.FullName;
    }
    if (!string.IsNullOrEmpty(candidate) && Directory.Exists(Path.Combine(candidate, "Views")))
    {
        projectDir = candidate;
    }
}

var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    Args = args,
    ContentRootPath = projectDir
});

// 1. Thêm cấu hình DbContext (Entity Framework Core với SQL Server)
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

// 2. Đăng ký các Services cho DI
builder.Services.AddScoped<IPasswordHasher, BcryptPasswordHasher>();
builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();
builder.Services.AddScoped<IAccountIdService, AccountIdService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IStreamerService, StreamerService>();
builder.Services.AddSingleton<IStreamerIdentityDocumentService, StreamerIdentityDocumentService>();
builder.Services.AddScoped<IAdminService, AdminService>();
builder.Services.AddScoped<IWidgetService, WidgetService>();
builder.Services.AddScoped<IQrCodeService, QrCodeService>();
builder.Services.AddHostedService<PendingWalletDepositExpirationService>();
builder.Services.AddHostedService<SupportConversationCleanupService>();
builder.Services.AddMemoryCache();
builder.Services.Configure<GhnOptions>(builder.Configuration.GetSection("GHN"));
builder.Services.AddHttpClient<IGhnShippingService, GhnShippingService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(15);
});
builder.Services.AddHttpClient<IStreamerBankQrService, StreamerBankQrService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(8);
});
builder.Services.Configure<SupportAiOptions>(builder.Configuration.GetSection(SupportAiOptions.SectionName));
builder.Services.AddHttpClient<ISupportAiService, OpenAiSupportService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(35);
});
builder.Services.Configure<DonateWeb.Areas.Widgets.Services.ElevenLabsOptions>(
    builder.Configuration.GetSection("ElevenLabs"));
builder.Services.AddHttpClient<DonateWeb.Areas.Widgets.Services.IElevenLabsTtsService,
    DonateWeb.Areas.Widgets.Services.ElevenLabsTtsService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
});
builder.Services.AddSingleton<DonateWeb.Areas.Widgets.Services.IDonationTtsAudioCache,
    DonateWeb.Areas.Widgets.Services.DonationTtsAudioCache>();

// Đăng ký Phân hệ Bảo mật & Kiểm duyệt (Content Moderation, Rate Limiting & Webhook Security)
builder.Services.AddSecurityAndModeration(builder.Configuration);

// Đăng ký dịch vụ SignalR cho cập nhật thời gian thực (OBS Alert, Thông báo thanh toán)
builder.Services.AddSignalR();

// Đăng ký PayOS Client SDK dạng Singleton
var payOSClientId = builder.Configuration["PayOS:ClientId"];
var payOSApiKey = builder.Configuration["PayOS:ApiKey"];
var payOSChecksumKey = builder.Configuration["PayOS:ChecksumKey"];
if (string.IsNullOrWhiteSpace(payOSClientId) || string.IsNullOrWhiteSpace(payOSApiKey) || string.IsNullOrWhiteSpace(payOSChecksumKey))
{
    throw new InvalidOperationException("PayOS is not configured. Set PayOS__ClientId, PayOS__ApiKey, and PayOS__ChecksumKey using environment variables or a secret store.");
}
var payOS = new DonateWeb.Services.PayOS(payOSClientId, payOSApiKey, payOSChecksumKey);
builder.Services.AddSingleton<DonateWeb.Services.IPayOSService>(payOS);

// 3. Cấu hình Authentication (Cookie và đăng nhập bên thứ ba)
var authBuilder = builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultSignInScheme = "ExternalCookie";
    options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
})
.AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
{
    options.LoginPath = "/Auth/Login";
    options.LogoutPath = "/Auth/Logout";
    options.AccessDeniedPath = "/Auth/AccessDenied";
    options.Cookie.Name = "DonateWeb.AuthCookie";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = builder.Environment.IsDevelopment()
        ? CookieSecurePolicy.SameAsRequest
        : CookieSecurePolicy.Always;
    options.ExpireTimeSpan = TimeSpan.FromDays(7);
    options.SlidingExpiration = true;
})
.AddCookie("ExternalCookie", options =>
{
    options.Cookie.Name = "DonateWeb.ExternalAuthCookie";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = builder.Environment.IsDevelopment()
        ? CookieSecurePolicy.SameAsRequest
        : CookieSecurePolicy.Always;
    options.ExpireTimeSpan = TimeSpan.FromMinutes(10);
});

// 3.1. Cấu hình đăng nhập bằng Google
var googleClientId = builder.Configuration["Authentication:Google:ClientId"];
var googleClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
authBuilder.AddGoogle("Google", options =>
{
    options.SignInScheme = "ExternalCookie";
    options.ClientId = !string.IsNullOrWhiteSpace(googleClientId) ? googleClientId : "YOUR_GOOGLE_CLIENT_ID";
    options.ClientSecret = !string.IsNullOrWhiteSpace(googleClientSecret) ? googleClientSecret : "YOUR_GOOGLE_CLIENT_SECRET";
    options.CallbackPath = "/signin-google";
    options.ClaimActions.MapJsonKey("urn:google:picture", "picture", "url");
    // Google OAuth v2 dùng verified_email; OpenID Connect chuẩn dùng email_verified.
    // Hỗ trợ cả hai định dạng để chỉ chấp nhận email được Google xác minh.
    options.ClaimActions.MapJsonKey("urn:google:email_verified", "verified_email");
    options.ClaimActions.MapJsonKey("urn:google:email_verified_oidc", "email_verified");
    options.Events.OnRemoteFailure = context =>
    {
        var errorMsg = Uri.EscapeDataString(context.Failure?.Message ?? "Đã hủy hoặc xảy ra lỗi xác thực Google.");
        context.Response.Redirect($"/Auth/ExternalLoginCallback?remoteError={errorMsg}");
        context.HandleResponse();
        return Task.CompletedTask;
    };
});

// 3.2. Cấu hình đăng nhập bằng Facebook
var facebookAppId = builder.Configuration["Authentication:Facebook:AppId"];
var facebookAppSecret = builder.Configuration["Authentication:Facebook:AppSecret"];
authBuilder.AddFacebook("Facebook", options =>
{
    options.SignInScheme = "ExternalCookie";
    options.AppId = !string.IsNullOrWhiteSpace(facebookAppId) ? facebookAppId : "YOUR_FACEBOOK_APP_ID";
    options.AppSecret = !string.IsNullOrWhiteSpace(facebookAppSecret) ? facebookAppSecret : "YOUR_FACEBOOK_APP_SECRET";
    options.CallbackPath = "/signin-facebook";
    options.Scope.Add("email");
    options.Fields.Add("picture");
    options.ClaimActions.MapJsonSubKey("urn:facebook:picture", "picture", "data", "url");
    options.Events.OnRemoteFailure = context =>
    {
        var errorMsg = Uri.EscapeDataString(context.Failure?.Message ?? "Đã hủy hoặc xảy ra lỗi xác thực Facebook.");
        context.Response.Redirect($"/Auth/ExternalLoginCallback?remoteError={errorMsg}");
        context.HandleResponse();
        return Task.CompletedTask;
    };
});

// 4. Cấu hình Phân quyền (RBAC - Role-based Access Control)
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireAdminRole", policy => policy.RequireRole(UserRoles.Admin));
    options.AddPolicy("RequireStreamerRole", policy => policy.RequireRole(UserRoles.Streamer));
    options.AddPolicy("RequireViewerRole", policy => policy.RequireRole(UserRoles.Viewer));
});

builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "RequestVerificationToken";
});

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // Chỉ tin proxy trong dải bridge mặc định của Docker; không tin forwarded header từ mọi IP.
    options.KnownIPNetworks.Add(System.Net.IPNetwork.Parse("172.16.0.0/12"));
});

var dataProtectionKeysPath = builder.Configuration["DataProtection:KeysPath"];
if (!string.IsNullOrWhiteSpace(dataProtectionKeysPath))
{
    builder.Services.AddDataProtection().PersistKeysToFileSystem(new DirectoryInfo(dataProtectionKeysPath));
}

builder.Services.AddSingleton<StreamerAgreementContentService>();
builder.Services.AddScoped<DonateWeb.Security.StreamerContractGateFilter>();
builder.Services.AddControllersWithViews(options =>
    options.Filters.AddService<DonateWeb.Security.StreamerContractGateFilter>());

var app = builder.Build();

// 5. Tự động khởi tạo Database và Seed dữ liệu mẫu (Roles, Admin, Streamer tenstreamer, Viewer)
using (var scope = app.Services.CreateScope())
{
    await DbInitializer.InitializeAsync(app.Services, app.Environment.IsDevelopment());
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseForwardedHeaders();
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Bật Authentication trước Authorization
app.UseAuthentication();
app.UseAuthorization();

// Ánh xạ SignalR Hub
app.MapHub<DonateWeb.Hubs.PaymentHub>("/paymentHub");
app.MapGet("/health", async (AppDbContext context, CancellationToken cancellationToken) =>
    await context.Database.CanConnectAsync(cancellationToken) ? Results.Ok(new { status = "healthy" }) : Results.StatusCode(StatusCodes.Status503ServiceUnavailable));

// Ánh xạ các API Controllers (bao gồm PaymentWebhookController và WidgetsApiController)
app.MapControllers();

// 6. Cấu hình Route cho Area Admin
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Admin}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "admin_shortcut",
    pattern: "Admin/{action=Index}/{id?}",
    defaults: new { area = "Admin", controller = "Admin" });

app.MapControllerRoute(
    name: "shop_shortcut",
    pattern: "Shop/{action=Index}/{id?}",
    defaults: new { controller = "Shop", action = "Index" });

// 7. Cấu hình Route cho Slug Streamer (ví dụ: domain.com/tenstreamer hoặc domain.com/domixi)
// Sử dụng regex để tránh xung đột với các route controller hoặc tài nguyên tĩnh
app.MapControllerRoute(
    name: "streamer_slug",
    pattern: "{slug:regex(^(?!api|auth|admin|widgets|home|profile|streamer|wallet|coupons|effects|orders|shop|transactions|guides|images|css|js|lib|favicon).*$)}",
    defaults: new { controller = "Streamer", action = "Donate" });

// Route mặc định
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
