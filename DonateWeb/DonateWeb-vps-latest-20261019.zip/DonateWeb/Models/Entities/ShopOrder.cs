using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DonateWeb.Models.Entities
{
    public class ShopOrder
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string OrderCode { get; set; } = string.Empty;

        /// <summary>
        /// SHA-256 hash of a random guest access token. Null for account-owned orders.
        /// </summary>
        [MaxLength(64)]
        public string? GuestAccessTokenHash { get; set; }

        public int StreamerProfileId { get; set; }
        [ForeignKey("StreamerProfileId")]
        public virtual StreamerProfile StreamerProfile { get; set; } = null!;

        public int? BuyerUserId { get; set; }
        [ForeignKey("BuyerUserId")]
        public virtual User? BuyerUser { get; set; }

        [Required]
        [MaxLength(100)]
        public string BuyerName { get; set; } = string.Empty;

        [MaxLength(30)]
        public string? BuyerPhone { get; set; }

        [MaxLength(300)]
        public string? BuyerAddress { get; set; }

        [MaxLength(500)]
        public string? Note { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal SubtotalAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal DiscountAmount { get; set; }

        [MaxLength(50)]
        public string? CouponCode { get; set; }

        public int? DiscountCouponId { get; set; }
        [ForeignKey(nameof(DiscountCouponId))]
        public virtual DiscountCoupon? DiscountCoupon { get; set; }

        [MaxLength(50)]
        public string PaymentMethod { get; set; } = "Wallet"; // 'Wallet' | 'VietQR'

        [MaxLength(50)]
        public string PaymentStatus { get; set; } = "Pending"; // 'Pending' | 'Paid' | 'Cancelled'

        /// <summary>
        /// Cho biết số lượng hàng của đơn PayOS đang chờ đã được giữ khỏi kho hay chưa.
        /// Khi thanh toán thành công, hàng vẫn bị trừ và cờ này được tắt; khi hủy thì hoàn kho.
        /// </summary>
        public bool StockReserved { get; set; }

        [MaxLength(100)]
        public string? TransactionCode { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? PaidAt { get; set; }

        public virtual ICollection<ShopOrderItem> Items { get; set; } = new List<ShopOrderItem>();
    }
}
